package com.mindtree.FSE;

public class Class3 {

	Class4 class4 = new Class4();

	

}
